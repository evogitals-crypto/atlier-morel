# Atelier Morel

Site vitrine statique : architecture et architecture intérieure.

## Aperçu

Ouvrir `index.html` dans un navigateur, ou servir ce dossier avec un serveur HTTP statique. Aucun build ni installation nécessaire.

## Fichiers

- `index.html` : contenu de la page
- `style.css` : mise en page et styles
- `app.js` : interactions et animations
- `motion.js` : trajectoires et interpolation
- `public/atelier-morel/` : photographies et logo fournis

Les animations respectent `prefers-reduced-motion`.
